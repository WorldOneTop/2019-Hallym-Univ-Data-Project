import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class FileSocket extends Thread{
	public static ServerSocket serverSocket;
	Socket socket;
	BufferedInputStream br;
	BufferedOutputStream bw;
	byte[] buf;
	boolean savefile;			// ������ �����Ϸ��� true  ������ �����Ÿ� false
	String path;
	public FileSocket(String path,boolean a) throws IOException {
		// TODO Auto-generated constructor stub
//		socket = s;
		this.path = path;
		buf = new byte[4096];
		savefile = a;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		try {
			
			socket = serverSocket.accept();
			
			if(savefile) {
				br = new BufferedInputStream((socket.getInputStream()));
				bw = new BufferedOutputStream(new FileOutputStream(path));		// �ӽ÷� ��θ� �ٲ㼭
			}																		// ������ �� �� ������ �������ϰ� ��
			else {
				br = new BufferedInputStream(new FileInputStream(path));		
				bw = new BufferedOutputStream((socket.getOutputStream()));
			}
			
			int read_length = 0;//���µ����� ����
			while((read_length = br.read(buf)) > 0 ){
			     bw.write(buf, 0 , read_length);
			     bw.flush();
			}
			bw.close();
			br.close();
			socket.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}