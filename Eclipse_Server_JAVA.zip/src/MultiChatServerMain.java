import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MultiChatServerMain {
    public static void main(String[] args) { 
        MultiChatServer server = new MultiChatServer();
        try {
			FileSocket.serverSocket = new ServerSocket(12345);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        try {
            ServerSocket serverSocket = new ServerSocket(12344);

            while (true) {//���� ��û �ٹޱ� ���ؼ� while true
                Socket socket = serverSocket.accept();
                System.out.println(socket.getRemoteSocketAddress() + " : ����");//���� Ȯ�� ����(ip�ּ�Ȯ��)
                server.addSocket(socket); 
            }
            
            
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }
 
    }
}